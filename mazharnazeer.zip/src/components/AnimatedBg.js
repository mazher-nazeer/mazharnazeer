import React from 'react'
import Styles from '../styles/Circles.module.css'

const AnimatedBg = () => {
    return (
            <ul className={Styles.circles}>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
        </ul>
    )
}

export default AnimatedBg