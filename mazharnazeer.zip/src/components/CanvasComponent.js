import React, { useEffect } from 'react'
import Styles from '../styles/Lcd.module.css'

const CanvasComponent = () => {
    return (
        <div className={Styles.distorted}></div>
    )
}

export default CanvasComponent