"use strict";
(() => {
var exports = {};
exports.id = 107;
exports.ids = [107];
exports.modules = {

/***/ 3940:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ ContactAPI)
});

;// CONCATENATED MODULE: external "nodemailer"
const external_nodemailer_namespaceObject = require("nodemailer");
var external_nodemailer_default = /*#__PURE__*/__webpack_require__.n(external_nodemailer_namespaceObject);
;// CONCATENATED MODULE: ./src/pages/api/contactform.js

async function ContactAPI(req, res) {
    const { name , email , phone , message  } = req.body;
    const user = process.env.USER_ID;
    const pass = process.env.USER_PASS;
    const data = {
        name,
        email,
        phone
    };
    const transporter = external_nodemailer_default().createTransport({
        host: "smtp.gmail.com",
        port: 465,
        secure: true,
        auth: {
            user: user,
            pass: pass
        }
    });
    try {
        const mail = await transporter.sendMail({
            from: user,
            to: user,
            replyTo: email,
            subject: `Contact form submission from ${name}`,
            html: `
            <h3>Name: ${name}</h3>
            <h3>Emil: ${email}</h3>
            <h3>Contact: ${phone}</h3>
            <h3>Message: ${message}</h3>`
        });
        console.log("Message sent: ", mail.messageId);
        return res.status(200).json({
            message: "success"
        });
    } catch (error) {
        console.log(error);
        res.status(500).json({
            message: "Your message was not sent!"
        });
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(3940));
module.exports = __webpack_exports__;

})();